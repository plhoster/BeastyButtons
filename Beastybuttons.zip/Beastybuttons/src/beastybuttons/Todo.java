package beastybuttons;

public class Todo {
	/*minimum:
	 * -> handlers 05.10.
	 * -> import/export system 15.10.
	 * -> Presets 17.10.
	 * -> Examples 19.10.
	 * -> (Virtual Keyboard) 20.10.
	 * -> Documentation 27.10.
	 * -> beschreibender Text 01.11.
	 */
}